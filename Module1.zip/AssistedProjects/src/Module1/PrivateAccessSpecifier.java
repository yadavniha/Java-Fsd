package Module1;

public class PrivateAccessSpecifier {
	public void show()
	{
		System.out.println("I'm a private access specifier");
	}

}
