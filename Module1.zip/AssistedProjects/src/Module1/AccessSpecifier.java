package Module1;

public class AccessSpecifier {
	void display()
	{
		System.out.println("I'm default access specifier");
	}

}
