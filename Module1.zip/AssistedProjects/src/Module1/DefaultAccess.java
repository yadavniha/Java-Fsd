package Module1;

public class DefaultAccess {
	public static void main(String[] args) {
		System.out.println("Default AccessSpecifier");
		AccessSpecifier obj = new AccessSpecifier();
		obj.display();
	}

}
