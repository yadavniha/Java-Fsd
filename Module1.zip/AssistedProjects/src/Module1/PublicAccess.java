package Module1;

public class PublicAccess {
	public void show()
	{
		System.out.println("I'm public access specifier");
	}
}
	
	


