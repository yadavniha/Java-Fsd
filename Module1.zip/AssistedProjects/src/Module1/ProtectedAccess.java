package Module1;

public class ProtectedAccess {
	public void display()
	{
		System.out.println("I'm protected pleae inherit the claass to access me");
	}

}
