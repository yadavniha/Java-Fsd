package pck2;
import Module1.*;
public class AccessSpecifiers1 extends ProtectedAccess {
	public static void main(String[] args) {
		ProtectedAccess p=new ProtectedAccess();
		p.display();
	}

}
