package pck2;
import Module1.*;
public class AccessSpecifiers {
	public static void main(String[] args) {
		PublicAccess p=new PublicAccess();
		p.show();
	}

}
