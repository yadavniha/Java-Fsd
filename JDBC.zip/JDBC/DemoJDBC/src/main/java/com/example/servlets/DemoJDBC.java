package com.example.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/DemoJDBC")
public class DemoJDBC extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Initialize JDBC connection
            Connection connection = DBConnection.initializeConnection();

            // Check if the connection is successful
            if (connection != null) {
                out.println("<html><body><h2>JDBC Connection Initialized Successfully!</h2></body></html>");

                // Perform any additional database operations here if needed

                // Close the JDBC connection
                DBConnection.closeConnection(connection);
            } else {
                out.println("<html><body><h2>Failed to initialize JDBC Connection</h2></body></html>");
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
            out.println("<html><body><h2>Error: " + e.getMessage() + "</h2></body></html>");
        }
    }
}
