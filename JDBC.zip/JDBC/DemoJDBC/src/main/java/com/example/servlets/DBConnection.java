package com.example.servlets;

import java.io.IOException;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
   
    public static Connection initializeConnection() throws SQLException, IOException {
        Properties properties = new Properties();
        try (InputStream input = DBConnection.class.getClassLoader().getResourceAsStream("config.properties"))
        {
        	    if (input != null) {
        	        System.out.println("config.properties loaded successfully.");
        	    } else {
        	        System.out.println("config.properties not found.");
        	    }
        	} catch (IOException e) {
        	    e.printStackTrace();
        	}
		return null;

            //properties.load(input);
        

       /*
          String url = properties.getProperty("db.url");
       
        String username = properties.getProperty("db.username");
        String password = properties.getProperty("db.password");
*/
        //return DriverManager.getConnection(url, username, password);
    }
    

    public static void closeConnection(Connection connection) 
    {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
