package com.ecommerce;

import java.io.IOException;


import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/DemoJDBC")
public class DemoJDBC extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public DemoJDBC() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	// TODO Auto-generated method stub
		
    			// DriverManager out;
    			PrintWriter out=response.getWriter();
    			try {
    		            // JDBC initialization code
    		            Class.forName("com.mysql.cj.jdbc.Driver");
    		            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce","root","12345");

    		          out.println("jdbc initilized");

    		            // Close JDBC resources
    		            connection.close();

    		            out.println("<h2>JDBC Initialized and Closed Successfully</h2>");
    		        } catch (Exception e) {
    		            out.println("<h2>Error: " + e.getMessage() + "</h2>");
    		        }

    			response.getWriter().append("Served at: ").append(request.getContextPath());
    		}

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handling POST requests, calling the doGet method
        doGet(request, response);
    }
}
