package com.ecommerce;
import java.io.IOException;

import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ProductDetails() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (
            PrintWriter out = response.getWriter();
            InputStream in = getServletContext().getResourceAsStream("/WEB-INF/config.properties")
        ) {
            Properties props = new Properties();
            props.load(in);

            // Use try-with-resources for Connection
            try (Connection conn = new DBConnection(props.getProperty("url"), props.getProperty("userid"),
                    props.getProperty("password")).getConnection()) {

                // Insert new product
                try (PreparedStatement pstmt = conn
                        .prepareStatement("INSERT INTO eproduct(name, price, date_added) VALUES (?, ?, current_timestamp)")) {
                    pstmt.setString(1, "New Product");
                    pstmt.setDouble(2, 17800.00);
                    pstmt.executeUpdate();
                }

                // Retrieve and display products
                try (Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                        ResultSet rst = stmt.executeQuery("SELECT * FROM eproduct")) {
                    out.println("<html><body>");
                    while (rst.next()) {
                        out.println(rst.getInt("ID") + ", " + rst.getString("name") + "<br>");
                    }
                    out.println("</body></html>");
                }
            }
        } catch (SQLException | IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
