import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<app-products-list></app-products-list>`,
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-app';
}
