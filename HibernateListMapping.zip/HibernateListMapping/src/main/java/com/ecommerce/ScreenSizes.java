package com.ecommerce;

public class ScreenSizes {
	
	 private long SCREENID;
     private String size;
     
     private EProduct product;
     
     public ScreenSizes(String size) {
         this.size = size;
     }

     
     public ScreenSizes(String size, EProduct product) {
         this.size = size;
         this.product = product;
     }

     // Getters and setters

     public long getSCREENID() {
         return SCREENID;
     }

     public void setSCREENID(long sCREENID) {
         SCREENID = sCREENID;
     }

     public String getSize() {
         return size;
     }

     public void setSize(String size) {
         this.size = size;
     }

     public EProduct getProduct() {
         return product;
     }

     public void setProduct(EProduct product) {
         this.product = product;
     }
 }
