package PracticeProject19;

public class DiamondProblemTest implements First, Second 
{  
    public void show() 
    {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]) 
    { 
        DiamondProblemTest ob = new DiamondProblemTest(); 
        ob.show(); 
    } 
}
