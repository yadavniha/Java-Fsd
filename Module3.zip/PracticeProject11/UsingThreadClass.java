package PracticeProject11;

public class UsingThreadClass extends Thread
{
 	public void run()
 	{
 	
 		
  		System.out.println("Thread using Thread Class started..");
 		
 	}


 	public static void main( String args[] )
 	{
  		UsingThreadClass m = new  UsingThreadClass();
  		m.start();
 	}
}

