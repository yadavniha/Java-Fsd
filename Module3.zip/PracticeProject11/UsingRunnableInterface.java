package PracticeProject11;

public class UsingRunnableInterface implements Runnable 
{
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println("Thread using Runnable Interface.."+i);
		}
		
		
	}
	public static void main(String[] args) {
		UsingRunnableInterface r=new UsingRunnableInterface();
		Thread m=new Thread(r);
		m.start();
	}

}
