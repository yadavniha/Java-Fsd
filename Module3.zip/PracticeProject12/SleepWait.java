package PracticeProject12;

public class SleepWait{
    private static Object b = new Object();
    public static void main(String args[]) throws InterruptedException
    {
        Thread.sleep(1000);
        System.out.println("Thread '" + Thread.currentThread().getName() + "' is woken after sleeping for 1 second");
        synchronized (b) 
        {
            b.wait(1000);
            System.out.println("Object '" + b + "' is woken after" + " waiting for 1 second");
        }
    }
}
