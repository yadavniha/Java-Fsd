import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/Dashboard")
public class Dashboard extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Dashboard() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        out.println("<html><body>");

        // Get the array of cookies from the request
        Cookie[] cookies = request.getCookies();

        // Flag to check if the "userid" cookie is found
        boolean userIdFound = false;

        // Iterate through cookies to find "userid"
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("userid".equals(cookie.getName()) && cookie.getValue() != null) {
                    userIdFound = true;
                    // Display user ID obtained from the cookie
                    out.println("UserId read from cookie: " + cookie.getValue() + "<br>");
                    break; // No need to continue iterating if we found the "userid" cookie
                }
            }
        }

        // If "userid" cookie is not found, display a message
        if (!userIdFound) {
            out.println("No UserId was found in the cookie.<br>");
        }

        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Delegate to the doGet method
        doGet(request, response);
    }
}
