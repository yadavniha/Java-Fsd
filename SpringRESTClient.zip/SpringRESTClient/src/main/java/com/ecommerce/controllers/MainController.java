package com.ecommerce.controllers;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.ecommerce.beans.Quote;

@Controller
public class MainController {

    @RequestMapping("/")
    @ResponseBody
    public ResponseEntity<List<Quote>> index() {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Quote[]> responseEntity = restTemplate.getForEntity("https://type.fit/api/quotes", Quote[].class);
        List<Quote> quotes = Arrays.asList(responseEntity.getBody());
        return new ResponseEntity<>(quotes, HttpStatus.OK);
    }
}
