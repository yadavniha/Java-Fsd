package PracticeProject21;



import java.util.Arrays;

public class SmallestElement {
    public static void main(String[] args) {
        int[] list = {10, 5, 8, 3, 2, 7, 1, 9, 6};
        
        // Sorting the list in ascending order
        Arrays.sort(list);
        
        // Finding the fourth smallest element
        int fourthSmallest = list[3];
        
        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }
}
