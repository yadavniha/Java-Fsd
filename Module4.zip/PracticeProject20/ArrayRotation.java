package PracticeProject20;

public class ArrayRotation {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int steps = 5;

        // Displaying the original array
        System.out.println("Original Array:");
        displayArray(array);

        // Right rotating the array by 5 steps
        rightRotateArray(array, steps);

        // Displaying the rotated array
        System.out.println("Rotated Array:");
        displayArray(array);
    }

    // Function to right rotate an array by 'steps' steps
    public static void rightRotateArray(int[] arr, int steps) {
        int length = arr.length;
        int[] temp = new int[length];

        // Copying the elements to a temporary array
        for (int i = 0; i < length; i++) {
            temp[i] = arr[i];
        }

        // Shifting the elements to the right by 'steps' steps
        for (int i = 0; i < length; i++) {
            arr[(i + steps) % length] = temp[i];
        }
    }

    // Function to display the elements of an array
    public static void displayArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
