package PracticeProject24;
public class SingleLinkedList {
    private Node head;

    private static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    public void deleteKey(int key) {
        Node current = head;
        Node prev = null;

        // If the key is found at the head
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

        // Search for the key in the list
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key is not present in the list
        if (current == null) {
            return;
        }

        // Remove the key from the list
        prev.next = current.next;
    }

    public void displayList() {
        Node current = head;

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        SingleLinkedList list = new SingleLinkedList();

        // Add elements to the linked list
        list.head = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);
        Node Fourth = new Node(4);

        list.head.next = second;
        second.next = third;
        third.next = Fourth;

        System.out.println("Linked List before deletion:");
        list.displayList();

        int key = 2;
        list.deleteKey(key);

        System.out.println("Linked List after deleting the first occurrence of key " + key + ":");
        list.displayList();
    }
}
