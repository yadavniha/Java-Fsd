package PracticeProject25;

public class circularLinkedList {
    private Node head;

    private static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    public void insert(int data) {
        Node newNode = new Node(data);

        // If the list is empty, make the new node the head
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else if (data <= head.data) {
            // If the new node is smaller than or equal to the head, insert it before the head
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            // Find the correct position to insert the new node
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void displayList() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    public static void main(String[] args) {
      circularLinkedList list = new circularLinkedList();

        // Add elements to the sorted circular linked list
        list.insert(3);
        list.insert(5);
        list.insert(8);
        list.insert(2);

        System.out.println("Sorted Circular Linked List:");
        list.displayList();
    }
}
