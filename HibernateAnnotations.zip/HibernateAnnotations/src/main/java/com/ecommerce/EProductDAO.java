package com.ecommerce;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class EProductDAO {
    public void saveEProduct(EProduct eProduct) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();
            session.save(eProduct);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
