package com.ecommerce;

import java.math.BigDecimal;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        EProduct eProduct = new EProduct();
        eProduct.setName("Product Name");
        eProduct.setPrice(new BigDecimal("19.99"));
        eProduct.setDateAdded(new Date());

        EProductDAO eProductDAO = new EProductDAO();
        eProductDAO.saveEProduct(eProduct);
    }
}
