package com.ecommerce;

import java.io.Serializable;

public class PDescription implements Serializable {

    private static final long serialVersionUID = 1L;

    private long descriptionId;
    private String descrip;

    public PDescription() {

    }

    public long getDescriptionId() {
        return descriptionId;
    }

    public void setDescriptionId(long descriptionId) {
        this.descriptionId = descriptionId;
    }

    public String getDescrip() {
        return descrip;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }
}
