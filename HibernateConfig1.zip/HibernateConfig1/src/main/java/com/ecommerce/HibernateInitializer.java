package com.ecommerce;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class HibernateInitializer implements ServletContextListener {
    
	private static SessionFactory sessionFactory;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
            // Create the Hibernate SessionFactory
            Configuration configuration = new Configuration().configure();
            sessionFactory = configuration.buildSessionFactory();

            // Set the SessionFactory in the application context
            sce.getServletContext().setAttribute("hibernateSessionFactory", sessionFactory);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // Clean up Hibernate resources when the application is shutting down
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
        }
    }
}