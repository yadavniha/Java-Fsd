package com.ecommerce;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;




import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/list")
public class ListProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Simulate fetching a list of products from a database or another source
        List<String> products = new ArrayList<>();
        products.add("Product 1");
        products.add("Product 2");
        products.add("Product 3");

        // Set the list of products as an attribute in the request
        request.setAttribute("products", products);

        // Forward the request to the JSP page for rendering
        request.getRequestDispatcher("/listProducts.jsp").forward(request, response);
    }
}

